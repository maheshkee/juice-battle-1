# RESEARCH.md
# Gas Cylinder Monitor — Research, Derivations & First-Principles Findings
# Era: ESP32-C3 node + UNO Q hub (V1)
# Last updated: 2026-06-04 (ESP32 pivot ingested)
# Rule: never delete entries — only append. Mark superseded entries clearly.

---

## Purpose

This document captures research findings, first-principles derivations, and
design decisions. Every entry is explicitly marked:

- **[PROVEN]** — verified by official source or direct measurement
- **[DERIVED]** — computed/reasoned from proven facts, not yet measured
- **[REASONED]** — design judgement, defensible but not yet measured
- **[PENDING]** — to be measured/decided

---

## PART I — ESP32-C3 ERA (CURRENT, from 2026-06-02 session)

---

## 1. The Product in One Line

A weighing scale (4× 20 kg load cells in final form; 1 cell + substitute weights in dev)
under an LPG cylinder. An **ESP32-C3 reads the weight**, sends it to an **Arduino UNO Q
acting as a hub ("SBC")**, which displays remaining gas (grams + %), tracks consumption,
finds usage patterns, and **predicts when the cylinder will run out**, reported daily.

---

## 2. KEY DOMAIN FACTS — Indian LPG  **[PROVEN, official]**

- **Net gas is regulation-fixed.** Domestic = **14.2 kg ± 150 g**. Pack sizes: **5 kg,
  14.2 kg** (domestic) and **19 kg, 47.5 kg, 425 kg** (commercial/industrial).
  - IOCL (net 14.2, empty ~15.5, gross ~29.7): https://www.iocl.com/MediaDetails/9580
  - BIS standard IS 3196 (Part 1)
- **Tare (steel/empty) weight is stamped on every cylinder** — varies by brand/batch
  (~14.5–15.8 kg for domestic). Total = stamped tare + net gas.

**The asymmetry that drives the whole design:**
- **Capacity** = tightly standardized → *classify* (pick from known set).
- **Steel (tare)** = loosely standardized, varies per cylinder → *measure*, never assume.

---

## 3. The Core Measurement Problem  **[DERIVED]**

The scale reports one number: `gross = steel + gas`. That is **one equation, two unknowns**
(steel, gas). A single reading is mathematically underdetermined.

Everything else is about supplying the missing equation cheaply, or waiting for an event
that supplies it.

---

## 4. The Percentage Truth (and the 52% Trap)  **[DERIVED]**

Steel never leaves the scale. A full domestic reads ~29.5 kg (≈15.3 steel + 14.2 gas);
an empty one still reads ~15.3 kg.

- **WRONG:** `gross / full × 100` → an *empty* cylinder reads ~52%. Worst possible failure.
- **RIGHT:** `gas_remaining = gross − steel; percentage = gas_remaining / 14200 × 100`.
  Empty = 0%, full = 100%.

→ **No honest % exists until the hub knows the steel weight.**

---

## 5. Two Stacked Calibration Layers (keep separate)  **[DERIVED]**

1. **`cal_factor`** — converts raw HX711 counts → grams. Hardware/MCU-specific.
   **Must be re-derived on the ESP32-C3** (the prior 106.7 raw/g was an STM32 figure,
   VOID on ESP32-C3). Never hardcoded; computed on boot or from config.
2. **steel / capacity** — converts grams → gas remaining + %. The domain layer logic.

A perfect layer 1 still needs layer 2, and vice versa. They are independent.

---

## 6. Anchor Events — How Steel & Capacity Are Learned  **[DERIVED]**

Two moments in a cylinder's life are self-revealing:

- **FULL INSTALL — the primary, guaranteed anchor.** A delivered cylinder is full, so
  `gas = capacity` and `gross_install = steel + capacity`. Classify capacity from the
  gross band → **`steel = gross_install − capacity`**. Fires on **every refill**,
  guaranteed within one cylinder lifetime. Accuracy ~±150 g (≈1%).
- **EMPTY FLOOR — opportunistic cross-check.** When gas ≈ 0, `gross ≈ steel`. Direct,
  exact, but only happens if the user runs to true empty. **Demoted to cross-check.**

Cross-check: `gross_install − steel` should match a catalog capacity.
Two independent routes to steel → system **converges and self-heals** over cycles.

---

## 7. Capacity Is Classifiable; Brand Is Invisible — and Irrelevant  **[DERIVED]**

- Full-weight **bands sit far apart** (full domestic ~29.5 kg vs full 19 kg commercial
  ~35+ kg) → **type/capacity is robustly classifiable** from gross.
- **Brand** (Indane/HP/Bharat) within a type differs only in steel by a few hundred grams.
  Cannot be read off gross, and is never needed: `steel = gross − capacity` *measures*
  that cylinder's steel directly, brand-agnostic.

---

## 8. Error Budget  **[PROVEN/DERIVED]**

- **Fill tolerance ±150 g (~1%)** is negligible for gauge and prediction:
  - It is a constant one-time offset → **cancels in any slope/difference**, so
    burn-rate and days-remaining are immune to it.
- **The real enemy is `cal_factor` drift** (temperature, mechanical creep, mounting):
  up to **~6.5% ≈ 923 g** on a full cylinder — **6× larger** than the fill tolerance.

---

## 9. Partial-Cylinder Cold Start — Solved Honestly  **[DERIVED]**

A partial cylinder of unknown type at first sight is **not solvable to a point by sensing
alone** (the underdetermined system of §3). Only two levers exist:

1. **Supply the missing equation** — user taps stamped tare → `steel` known → `gas = gross − steel`.
2. **Wait for an observed known-state event** — refill or run-to-empty — which pins `g`
   and back-solves steel permanently.

**What we CAN do without input — bound it to an interval:**
`gas ∈ [gross − steel_max, gross − steel_min]`, clamped to `[0, capacity]`.
Width ≈ ±5%. Report conservative (low-gas) end → never strand the user.

The truly blind case is **only first power-on with cylinder already present** — it is a
**one-time** event. Every later swap is fully observed. Collapses to exact at first refill.

---

## 10. Δ-Tracking Is Immune to Every Unknown  **[DERIVED]**

`used = weight_earlier − weight_later`. A difference cancels steel, capacity, and brand.
**Usage, burn rate, and patterns work from day one with zero calibration.** Only the
absolute % gauge and days-remaining require steel/capacity.

→ Cold start degrades gracefully: analytics exact immediately; gauge/prediction sharpen
at first refill.

---

## 11. Sampling Strategy — LOCKED  **[REASONED]**

**Sampling ≠ recording.** Two rates:
- **Internal read (fast, every few seconds):** not stored; answers pull requests instantly.
- **Heartbeat record (slow, every 15 min):** the **authoritative time-grid** stored to disk.
  Feeds prediction + hourly/daily analytics. ~96 rows/day is trivial.

Layered on top:
- **Event/session record** on a sustained drop past N ≈ 30–50 g with hysteresis.
- **Pull on demand** — answered from the latest internal read.

**Why a uniform grid (not adaptive):** idle readings are evidence, not waste — they prove
node liveness (heartbeat), anchor the trend line's flat stretches, and are the **only** way
to catch a leak. Don't optimize a cost that isn't a constraint.

---

## 12. Power — USB, LOCKED  **[REASONED]**

The electronics are part of the **scale**, not the cylinder → stationary, fixed location.
Battery trilemma: a battery node can have at most two of {instant pull, long life, simple
firmware}. USB dissolves the trilemma. Battery deferred to v1.x.

---

## 13. Engineering Principles Carried Forward (MCU-Agnostic)

- **HX711 raw bit-bang, no library.** 24-bit read + 25th gain pulse (gain 128, ch A).
  Sign-extend: `if (v & 0x800000) v |= 0xFF000000`. `wait_ready` polls DOUT LOW,
  timeout → LONG_MIN. `noInterrupts()` around the clocking loop; `delayMicroseconds(1)`
  per edge. **Three corrupt-value filters mandatory: LONG_MIN, -1, 0x7FFFFF.**
- **Modular result-struct contract:** every module returns `{value, quality(GOOD/DEGRADED/FAILED), diagnosis}`.
- **Modules receive raw readings injected by the orchestrator** — never call HX711 directly.
  Enables multi-cell scaling AND clean MCU swap.
- **Non-blocking, one-sample-per-loop, millis() pacing at top of loop.**
- **`float` is the safe default** (the double-broken bug was STM32U585-specific;
  **re-verify on ESP32-C3** — double may be fine, but float is the safe default).
- **Adaptive retry** (2s/10s/30s/60s backoff) + degraded operation — never halt in production.
- **No hardcoding:** cal_factor, thresholds, steel/capacity always derived or from config.

---

## 14. Analog Wiring Noise — Carried Hardware Reality  **[PENDING]**

HX711 ↔ load cell is on jumper wires. Empty-scale per-sample noise drifted 100 → 587 raw
(~1 → 5.6 g), trending up. Tare DC is rock-solid → the cell is fine; this is **signal-path
contact noise on the mV analog hop, amplified 128×**.

**Recommendation:** harden the 4 analog connections (solder / screw terminal, short leads)
before trusting fine measurements. **This problem moves with the HX711 onto the ESP32-C3.**

---

## 15. New ESP32-C3 Concerns (Flag Early)  **[PENDING]**

- **Voltage:** HX711 wants **5 V VCC** for full excitation; ESP32-C3 is a **3.3 V** part.
  The STM32's D7/D6 were 5V-tolerant. **ESP32-C3 GPIO tolerance vs HX711 DOUT/SCK levels
  must be checked; level-shifting may be needed.**
- **Pins:** the "DT=D7/SCK=D6 only" rule was an STM32U585 *timer-conflict* constraint —
  it does **NOT** apply to the ESP32-C3. Pick two GPIO, validate on ESP32.
- **float vs double:** the double-broken bug was STM32U585-specific. Re-verify on ESP32-C3
  (double may be fine; use float as safe default until verified).
- **cal_factor:** the prior value of 106.7 raw/g was STM32U585-specific. VOID on ESP32-C3.
  Re-derive completely.

---

## 16. Open Questions — ESP32-C3 Era

| # | Question | Raised | Status |
|---|----------|--------|--------|
| 1 | 3.3V logic-level compatibility with HX711 at 5V VCC | 2026-06-02 | ❓ PENDING E-000 |
| 2 | Correct GPIO pin pair for ESP32-C3 + HX711 | 2026-06-02 | ❓ PENDING E-000 |
| 3 | cal_factor on ESP32-C3 (was 106.7 on STM32 — VOID) | 2026-06-02 | ❓ PENDING |
| 4 | Cal_factor linearity across weight range | 2026-05-05 | PROVEN 2026-06-12 - 3-cell 200g to 1800g, CV=4.1% |
| 5 | Noise floor on ESP32-C3 (drifted to ~5.6g on STM32 — wiring issue) | 2026-06-02 | ❓ PENDING |
| 6 | Thermal drift magnitude and whether software cross-checks swamp it | 2026-06-02 | ❓ Post-MVP |
| 7 | Actual minimum detectable removal on ESP32-C3 | 2026-06-02 | RESOLVED 2026-06-17 — min=20g (1 trial), hard floor=10g |
| 8 | False positive rate of delay-line detector on static load | 2026-06-17 | RESOLVED 2026-06-17 — 0 false triggers in 38.4 min. PASS. |
| 9 | 190g drift over 38 min on static load — thermal? mechanical creep? | 2026-06-17 | ❓ PENDING 3E-009 long-run stability soak |
| 10 | HUB-001 BLE command protocol — single byte opcode? JSON? | 2026-06-17 | ❓ Design needed before node BLE work |

---

---

## PART II — STM32 ERA (SUPERSEDED — archived for history)

> The following entries were written when the STM32U585 MCU on the UNO Q read the HX711
> directly. That architecture is superseded. The ESP32-C3 is now the sensor node.
> See docs/reference/HANDOFF_ESP32_PIVOT.md for the pivot decision record.
> STM32 hardware constants (DT=D7, SCK=D6, cal_factor=106.7) are VOID on ESP32-C3.

---

## STM-1. Why Self-Characterisation — The Core Philosophy

### Finding (2026-05-05)

Every installation is different. Hardcoded constants assume all environments
are identical. They are not.

**Hardware proof — same board, same bench, two runs same day:**

```
Run 1 STD = 2.3636g → THRESHOLD = 4.2281g
Run 2 STD = 1.3315g → THRESHOLD = 2.3819g
```

Nearly 2× difference in STD on same hardware same day.

**Conclusion:** Tare, cal_factor, and noise threshold must ALL be self-computed
at appropriate times. Nothing hardcoded except sanity bounds.

| Constant        | Approach              | Status |
|-----------------|-----------------------|--------|
| tare_raw        | Self-computing        | ✅ Verified (STM32, VOID on ESP32) |
| cal_factor      | Self-computing        | ✅ Verified (STM32, VOID on ESP32) |
| noise threshold | Self-computing        | ✅ Verified (STM32, VOID on ESP32) |

---

## STM-2. LPG Consumption Derivation — Indian Household

### Source data (Indian LPG standard, government documented)

```
Cylinder net gas weight : 14,200g (fixed by regulation, all brands)
Typical duration        : 30 days per cylinder
Average daily cooking   : 2.5 hours active flame
```

### Derivation (📐 DERIVED)

```
Daily consumption    = 14,200g ÷ 30 days         = 473g/day
Hourly consumption   = 473g   ÷ 2.5 hours        = 189g/hour
Per-minute burn rate = 189g   ÷ 60 minutes       = 3.15g/min
```

**NOTE:** This is a government average. V1 product derives personalised burn rate
from actual data — no government average is ever used in the product.

---

## STM-3. Sliding Window Delta Detector — Theory

### Problem with single-sample detection

```
Single sample noise PP  ≈ 7.5g (from experiment 003 clean run on STM32)
Min event               = 16g (estimated, not yet measured)
Margin                  = 16 / 7.5 = 2.1×  ← too tight
```

### Solution — two sliding windows of N=10

```
delta_std = √2 × (single_std / √N)

For single_std = 2.36g (worst case):
    delta_std = √2 × (2.36 / 3.16) = 1.06g
    4σ threshold = 4.23g
    margin = 16 / 4.23 = 3.8×  ← acceptable
```

This is theoretical. Experiment 007B (on ESP32) validates actual false positive rate.

---

## STM-4. Noise Sample Count — Statistical Derivation (2026-05-06)

```
N=200 : experiments only — lab reference, maximum accuracy (~44s boot)
N=50  : production boot — sufficient accuracy (~11s boot)
N=20  : rejected — 16% error cuts detection margin below 2×

Standard Error of STD = STD / sqrt(2 × N)
N=50 → ±10% threshold error → worst threshold 7.03 × 1.10 = 7.73g → margin 2.07× safe
```

Must re-verify timing on ESP32-C3 (different MCU speed + HX711 rate affects boot time).

---

## STM-5. STM32U585-Specific Bug Records

```
double accumulator in for loop → sum=0 on STM32U585
double array on stack in loop() → stack corruption → hang
DT=D7/SCK=D6 ONLY on STM32 → timer conflicts on D2-D5 (does NOT apply to ESP32-C3)
CAL_FACTOR = 106.7 raw/g on STM32 (VOID — re-derive on ESP32)
```

---

## STM-6. Proven Ranges (STM32 AQ3 — VOID on ESP32)

```
TARE range          : -12799 to -13737 raw (STM32 specific)
CAL_FACTOR range    : 100–107 raw/g (STM32 specific, VOID on ESP32)
NOISE STD range     : 1.33–3.93g (varies — must re-characterise on ESP32)
wait_ready timeout  : 400ms (tuned for AQ3 under Bridge load — re-tune on ESP32)
```

---

## ESP32-C3 specific findings - confirmed 2026-06-04

### Pinout (SuperMini HW-466AB)
Left side top to bottom: 5V, G, 3V3, 4, 3, 2, 1, 0
Right side top to bottom: 5, 6, 7, 8, 9, 10, 20, 21

### Safe HX711 pins confirmed
DOUT: GPIO4, SCK: GPIO3 - confirmed working, no boot interference

### cal_factor on ESP32 - rough estimate only
~113 raw/g - specific to this ESP32+GISLAB HX711+YZC161A combination
STM32 value of 106.7 raw/g is VOID on ESP32. Never carry over across MCUs.
E-001 will derive properly from known weights.

### 3.3V VDD confirmed working
GISLAB HX711 module works correctly at 3.3V VDD.
DOUT swings at 3.3V - safe for ESP32-C3 GPIO. No level shifter needed.

---

## ESP32-C3 Session 2 findings - 2026-06-05

### cal_factor confirmed range (ESP32-C3 + GISLAB HX711 + YZC-161A, 3.3V VDD)
- Stable range (reference >200g): 104.84 - 105.50 raw/g
- Variation: 0.6% across 227g-257g
- Unreliable range (reference <100g): 29.5 - 97.8 raw/g (SNR too low)
- Locked production value: ~105 raw/g [DERIVED - pending Experiment 005 for full range]

### Serial input on ESP32-C3 Arduino
- Serial.setTimeout(30000) required before readStringUntil - default 1000ms times out too fast
- Serial buffer contains stale \n from Serial Monitor open event
- Flush required: while (Serial.available()) Serial.read() before every user input prompt
- Without flush: readStringUntil returns empty string immediately, toFloat("") = 0.0

### Load cell settle time
- 10 seconds after load placement required for mechanical creep to reach equilibrium
- Sampling before settle = systematically biased cal_factor
- millis() countdown preferred over delay() - keeps Serial responsive during wait

---

## E-002 Noise Floor - ESP32-C3 + GISLAB HX711 + YZC-161A - 2026-06-08

### Confirmed noise floor values (hardware verified, two clean runs)

| Parameter | Value | Condition |
|---|---|---|
| Noise STD | 0.62-0.67g | 3-30 min power off, truly settled |
| Peak-to-peak | 3.18-3.47g | same conditions |
| Threshold 4xSTD | 2.48-2.67g | production value: 2.67g (conservative) |
| Settle reads | 22 (both runs) | dynamic detection, 10Hz HX711 |
| Settle time | ~2.2 seconds | both runs consistent |
| HX711 rate | 10Hz confirmed | RATE pin LOW on GISLAB green PCB module |
| Fan effect | +0.07g on STD | negligible - ceiling fan not a concern |

### Stability detection parameters (locked)

| Parameter | Value | Why |
|---|---|---|
| STAB_WINDOW | 20 samples | rolling window size |
| STAB_SPREAD | 2.5g | max allowed spread within one window |
| STAB_MEAN_DIFF | 1.0g | max allowed mean drift between consecutive windows |
| STAB_CONFIRM | 3 | consecutive passing windows required |
| TARE_SAMPLES | 20 | post-settle tare derivation sample count |

### vs STM32 comparison

ESP32-C3 STD 0.67g is better than STM32 1.87g (experiment 003, AQ3 STM32 era).
Likely because GISLAB HX711 at 3.3V with USB LDO is quieter than AQ3 5V regulated
supply for this specific module. Hardware-specific - do not generalise.

---

## 13. BLE Transport - QRB2210 Platform Findings (2026-06-08) — PROVEN

### bleak service_uuids filter behaviour
Tested: BleakScanner(service_uuids=[UUID]).discover(timeout=10.0) on QRB2210
running Debian Linux, BlueZ 5.x, bleak 0.21+.
Result: filter NOT enforced at scan level. All nearby BLE devices returned
regardless of advertised service UUIDs (14-15 devices observed).
Fix: application-layer name filter. See L-020.

### BLE radio noise coupling to HX711
Measured: STD 0.62-0.67g with BLE stack off (E-002).
Measured: STD 1.81g with BLE stack running (E-003).
Conclusion: BLE radio causes ~3× noise increase via power rail coupling.
Always characterise noise with BLE running for production values.
Production threshold: 7.24g (4 × 1.81g). See L-022.

### ESP32-C3 BLE MAC address
Hardware: ESP32-C3 SuperMini HW-466AB
MAC address: 10:00:3B:CD:63:32
Type: static hardware MAC derived from chip eFuse - does not rotate.
BlueZ on QRB2210 sees real hardware MAC, not randomised address.
MAC caching in config.json is reliable and stable.

---

## 13. 3-Cell Platform Characterisation - Hardware-Verified 2026-06-12

Platform: 3x YZC-161A 20kg load cells in parallel, shared plate, ESP32-C3 SuperMini, GISLAB HX711 at 3.3V.

### cal_factor - PROVEN
cal_factor = 36.1 raw/g
Method: self-characterising v5.2 sketch, 3 stages, ~80 clean readings
Range: 200g to 1800g all within ±8% of mean (CV = 4.1%)
Physics: 3-cell parallel → 1/3 single-cell sensitivity → 106.7/3 = 35.6 predicted, 36.1 measured

### Linearity - PROVEN
Linear from 200g to 1800g (9x range). No systematic curvature detected.
Single cal_factor valid across full cylinder weight range (15.5kg to 29.7kg).
100g class unreliable - tare walk dominates at that SNR.

### Settling times - PROVEN
Cold boot, no plate:   3 to 12s
Cold boot, with plate: 60 to 161s
Placement settle:      10s sufficient (loaded_std at or below noise_std in all runs)
Removal re-tare:       6s fast path, up to 86s after heavy loads

### Noise floor - OPEN
noise_std_raw during cal_factor runs: 72 to 188 raw (varies by thermal state)
In grams: 2.0g to 5.2g
BLE-on noise floor not yet measured - required by 3E-002.
E-003 values (STD=1.81g, threshold=7.24g) VOID for 3-cell platform.

### Minimum reliable weight - PROVEN
100g unreliable, 200g reliable.
Threshold: ~150g (SNR = 150g x 36.1 / 150 raw noise ~ 36x, above 20x minimum)

---

## 2026-06-17 — Boot timing and journal architecture confirmed on hardware

### Boot phase durations — ✅ PROVEN on 3-cell ESP32-C3
| Phase | Duration | Derivation |
|---|---|---|
| SETTLE | 2.1s | Fixed 2000ms mechanical settle wait |
| TARE | ~21s | 200 samples × 100ms (HX711 at 10 SPS) |
| NOISE | ~20s | 200 samples × 100ms (HX711 at 10 SPS) |
| CAL | variable | Waits for human weight placement + Serial input |
| Total (excl. CAL wait) | ~43s | SETTLE + TARE + NOISE |

HX711 sample rate confirmed 10 SPS — matches datasheet. No drift.

### Journal module confirmed working — ✅ PROVEN
- journal.cpp service module: sequence numbers, boot counter, event-based output
- Boot counter persisted in config.json — survives resets
- Event rate: ~13 lines for full boot + weight placement sequence
- vs old per-tick output: 216,000 lines/6hr reduced to ~750 lines
- Heartbeat 30s confirmed firing on schedule

### tick_ms finding — ✅ PROVEN
Per-tick loop time in STATE_RUNNING = 0–1ms. The entire reading cycle
(HX711 read → health check → BLE notify) completes in under 1ms as measured
by millis() difference. HX711 blocks internally during the 25-pulse read
sequence — that time is not captured by millis() around the loop body.

---

## 2026-06-17 — BLE transport verified end-to-end, BlueZ bugs documented

Platform: QRB2210 BlueZ backend inside App Lab Docker container

✅ PROVEN: bluetoothctl can scan and connect to ESP32-C3 NimBLE device
✅ PROVEN: Python dbus-python can connect via same D-Bus path
✅ PROVEN: Full pipeline node→BLE→hub→WebUI working on real hardware
✅ PROVEN: hcitool lescan always fails on this platform (HCI socket blocked)

BlueZ bugs confirmed on QRB2210:
- UUIDs filter in SetDiscoveryFilter: IGNORED
- UUIDs in InterfacesAdded payload: EMPTY (populated only after ServicesResolved)
- InterfacesAdded not fired for cached/known devices

Workarounds confirmed working:
- Name-based matching in _interfaces_added()
- _check_known_devices() at startup via GetManagedObjects()
- Transport='le' only in SetDiscoveryFilter (auto transport kills adapter)

Setup requirement: passwordless sudo for dbus-bridge service
File: /etc/sudoers.d/gas-cylinder-monitor
Required command: /usr/bin/systemctl restart/start/stop/status dbus-bridge-gas-cylinder-monitor.service

---

## 3E-006B — Minimum Detectable Removal — Hardware Results 2026-06-17

Platform: 3-cell YZC-161A parallel, GISLAB HX711, ESP32-C3 SuperMini.
sigma this session: 3.65g → threshold = 4 × 3.65g = 14.6g

### Method
Water container on platform. Remove precise water amounts with measuring cup.
Start large (200g), step down until detection fails.

### Results

| Removed (g) | Detected? | Notes |
|---|---|---|
| 200g | YES | Strong detection, delta >> threshold |
| 100g | YES | Strong detection |
| 50g | YES | Clear detection |
| 20g | YES | Detected above 14.6g threshold (~0.94× removed weight due to creep) |
| 10g | NO | Below threshold — hard floor |

### Key findings — [PROVEN]
- Minimum detectable removal = **20g** (1 trial, confirmed)
- Hard floor = **10g** — not detected
- Delay-line detector is slightly more sensitive than pure 4σ theory:
  load cell creep adds to measured delta over the 20-tick observation window
- Creep contribution means actual delta > applied weight for slow-load changes

### Detector fix made this session
Root cause: weight event detection was in journal.cpp (tick-to-tick delta, wrong module).
Fix: moved to weight.cpp — 20-tick delay-line comparator + s_event_pending lockout flag.
Result: single WEIGHT_EVENT per physical removal, no cascade events.

### API changes after fix
- weight_update() signature: `(long raw, float tare_raw, float cal_factor, float sigma_g)` — 4 args
- WeightResult gains `event` (WEIGHT_EVENT_NONE/PLACED/REMOVED) and `delta` fields
- journal_run() signature: `(float grams, float sigma, const HealthResult&, WeightEvent, float delta)` — 5 args

---

## 3E-007B — False Positive Rate — Hardware Results 2026-06-17

Platform: 3-cell YZC-161A parallel, GISLAB HX711, ESP32-C3 SuperMini.
sigma this session: 5.12g → threshold = 4 × 5.12g = 20.5g

### Method
Static load (water container) on platform. No intentional disturbances.
Observe WEIGHT_EVENT count over 38.4 minutes (2304 seconds).
Target: fewer than 2 false triggers per hour.

### Results — [PROVEN]

| Metric | Target | Observed | Status |
|---|---|---|---|
| False WEIGHT_EVENT triggers | < 2 per hour | 0 | ✅ PASS |
| Static load drift | (observation only) | 190g peak-to-trough | recorded |
| Observation window | > 30 minutes | 38.4 minutes | ✅ |

### Key findings
- Delay-line detector is completely immune to slow drift at this drift rate
- Drift rate: ~190g over 38 min ≈ 0.08g per 2-second tick
- Delta over 20 ticks ≈ 0.08 × 20 = 1.6g — far below 20.5g threshold
- 190g total drift is real slow drift (not noise) — thermal or mechanical creep
- Must be characterised in 3E-009 (long-run stability soak, 24hr)
- If uncorrected, will corrupt gas% at ~190g/38min ≈ 5g/min rate over long cycles

---

## Change Log

| Date | Entry |
|------|-------|
| 2026-05-05 | Created (STM32 era) |
| 2026-05-06 | Added entries 3–12 (STM32 era) |
| 2026-06-04 | MAJOR: ESP32 pivot — Part I is new canonical; Part II archived as SUPERSEDED |
| 2026-06-04 Session 2 | Added ESP32-C3 pinout, safe pins, rough cal_factor, 3.3V VDD confirmed |
| 2026-06-05 | E-001 complete. cal_factor ~105 raw/g confirmed. Serial drain and settle rules added. |
| 2026-06-08 | E-002 noise floor confirmed on ESP32-C3. STD 0.62-0.67g. Threshold 2.67g locked. Dynamic stability detection parameters locked. |
| 2026-06-08 | Added section 13 - BLE transport QRB2210 platform findings (E-003) |
| 2026-06-12 | Section 13 added - 3-cell platform hardware characterisation complete |

---
## 3-Cell Platform Accuracy — Confirmed 2026-06-16

### Finding
With cal_factor and tare derived in the same boot (3E004 sketch):
- Zero accuracy: ±4g (empty platform reads −3.6g to −2.1g)
- Weight accuracy: ±7g across 200g–1700g
- 700g: reads 699–706g (±5g, 0.7%)
- 1700g: reads 1702–1707g (±5g, 0.3%)
- 1800g: reads 1802g (+2g, 0.1%)

### Cal_factor this session
35.98 raw/g — derived from 1000g reference weight, same boot as measurement.
Previous locked value of 36.1 (2026-06-12) was consistent — within 0.3%.
Previous value of 31.51 was derived from a different boot — invalid cross-boot use.

### Noise floor this session
noise_std_raw: 173.98 counts
noise_std_g:   4.84g
threshold_g:   19.34g (4 × STD)

---

## 2026-06-16 - gas_monitor_v1 modular sketch verified

Platform: 3-cell YZC-161A parallel, GISLAB HX711, ESP32-C3 SuperMini

Confirmed values this session:
- cal_factor: 37.06 raw/g (3-cell, consistent with 3E-001 ~36 raw/g)
- sigma: 2.64g (recomputed post-CAL from boot-time noise samples)
- Boot sequence: SETTLE(2s) → TARE(200-sample) → NOISE(200-sample) →
  CAL(50-sample) → RUNNING confirmed working end-to-end

Arduino library dependencies confirmed required:
- NimBLE-Arduino by h2zero
- ArduinoJson by Benoit Blanchon

Known: NOISE WARNING "sigma too high" fires at boot - raw-unit sigma
(~95 raw) exceeds 20g gram-unit guard. Orchestrator correctly ignores
and continues. Log clarity issue, not functional bug.

| Date | Change |
|------|--------|
| 2026-06-16 | gas_monitor_v1 modular sketch verified on 3-cell hardware |
| 2026-06-16 | health.h + health.cpp added. Runtime jump detection verified on hardware. cstdio include required for snprintf on ESP32. |

---

## 2026-06-16 - Health Module Hardware Verification

**Board:** ESP32-C3 SuperMini
**Sketch:** node/gas_monitor_v1/gas_monitor_v1.ino (with health.h / health.cpp)
**Session:** Session 3 - 1B

### Confirmed hardware behaviour

**Runtime jump detection:**
- Empty platform (post-tare): ~0g
- Placed ~1kg weight: first reading 1009.1g
- Delta = 1009g - exceeded 500g threshold
- health_check() correctly returned quality=FAILED, diagnosis="stuck:|jump:1009g", checks=0x05
- Subsequent readings: delta < 500g, jump check passed, quality returned to DEGRADED

**Stuck check behaviour (known limitation):**
- tare_variance_raw = 0.0f (tare.h does not expose variance)
- Bit 1 (stuck_ok) always 0 - stuck check always fails
- Result: platform always reports DEGRADED in steady state
- This is correct and expected behaviour until TODO 1B-stuck is resolved

**Erratic and cal drift checks:**
- Both skip on every boot (prev_sigma_g = -1.0f, prev_cal_factor = -1.0f sentinels)
- First-boot path confirmed working - no false alarms
- Will remain skipped until TODO 1B-persistence is resolved

**cal_factor this session:** 35.84 raw/g (slightly lower than locked ~37 - within normal boot-to-boot variation)
**sigma recomputed:** 3.44g (slightly higher than session 2 value of 2.64g - within normal variation)

### Toolchain confirmed
- Arduino IDE v3.0.7 on Windows
- esp32 by Espressif v3.0.7
- Board: ESP32C3 Dev Module, COM11, USB CDC On Boot: ENABLED
- #include <cstdio> required for snprintf on ESP32 Arduino toolchain (not in <math.h>)

---

## Drift budget — V1 alert accuracy (from boot=37 journal data)

Measured on 3-cell YZC-161A platform, 1000g load, ambient kitchen conditions.

| Metric | Value |
|--------|-------|
| Drift rate typical | ~12.6g/hr |
| Drift rate worst case | ~25g/hr (temperature oscillation) |
| Max single-session drift (6hr) | ~150g worst case |
| Drift character | Non-monotonic — oscillates with temperature |
| Zero drift vs span drift | Primarily zero drift — does NOT scale with load |

Implication: same ±150g error budget applies regardless of cylinder weight.
A 29.5kg cylinder drifts the same absolute amount as a 1kg test weight.

Alert accuracy at V1 thresholds:
- Amber (2000g): fires at 1850g–2150g actual → ±0.4 days error at 350g/day
- Red   (1000g): fires at  850g–1150g actual → ±0.4 days error at 350g/day

Verdict: acceptable for V1. User gets 5–6 days warning at amber.
Drift does not cause false alerts under normal conditions.

Source: boot=37 journal, lines 032–258, 110 minutes static load.
Experiment 3E-009 (long-run 6hr stability) will produce the definitive budget.

---

## BT Watchdog — Threshold Derivations

**BT_FAILURE_SOFT_THRESHOLD = 120s**
Rationale: normal BLE reconnect after drop takes <30s.
2 minutes = 4× normal reconnect time. Safe margin before escalating to adapter reset.

**BT_FAILURE_ADAPTER_THRESHOLD = 300s**
Rationale: modprobe + bluetooth restart takes ~15s.
5 minutes total = time for 2–3 Level 1 attempts plus adapter reset.
If still failing after 5 min, adapter is truly wedged.

**BT_FAILURE_REBOOT_THRESHOLD = 600s**
Rationale: 10 minutes covers Level 1 + Level 2 attempts with margin.
In production 6hr duty cycle, 10 min silent failure is acceptable.
Family cooking dinner won't notice a 30s reboot.
Must not be longer than one duty cycle (360 min).

---

## Heap Memory Baseline — ESP32-C3, gas_monitor_v1, 2026-07-02

**heap_max_block on fresh flash (boot 45):** 114676 bytes (MALLOC_CAP_8BIT)
Observed across: 14+ heartbeats post-flash, no load changes, no BLE reconnect events.
Variance: 0 bytes — value was identical across all observed HB lines.
This is the reference baseline for detecting future heap fragmentation trends.
A declining trend across boots or across a long run would indicate a fragmentation or leak.

---

## HEAVY_LOAD_THRESHOLD_G — Source-Verified Value, 2026-07-02

**Value:** 2000.0f (grams)
**Location:** node/gas_monitor_v1/ (weight module)
**Verification method:** direct source read, session 61
**Status:** PRODUCTION value already in firmware — no revert needed. Previously tracked as pending at 1000g (DEV); that was incorrect.
